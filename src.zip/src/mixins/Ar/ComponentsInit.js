import HeaderSection from "@/components/AR/components/HeaderSection"
export default{
    components:{
        HeaderSection
    }
}