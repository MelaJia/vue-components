<template>
  <nav class="nav-menu">
      <el-menu :default-active="activeIndex" :router="true" class="el-menu-demo" mode="vertical" @select="handleSelect">
      <el-submenu index="1">
        <template slot="title">
          <div class="start-line"></div>
          <div class="header-circle bg-icon-1"></div>
          <span>AR管理</span>
        </template>
          <el-menu-item index="myar">
            <template slot="title">
              <div class="line"></div>
              <div class="circle"></div>
              <span>我的AR</span>
            </template>
          </el-menu-item>
          <el-menu-item index="getar">
            <template slot="title">
              <div class="line"></div>
              <div class="circle"></div>
              <span>待收AR</span>
            </template>
          </el-menu-item>
          <el-menu-item index="cancelar">
            <template slot="title">
              <div class="line"></div>
              <div class="circle"></div>
              <span>取消转让</span>
            </template>
          </el-menu-item>
          <el-menu-item index="historyar">
            <template slot="title">
              <div class="line"></div>
              <div class="circle"></div>
              <span>历史AR</span>
            </template>
          </el-menu-item>
      </el-submenu>
      <el-menu-item index="plan" disabled>
        <template slot="title">
          <div class="line"></div>
          <div class="header-circle bg-icon-2"></div>
          <span>资金管理</span>
        </template>
      </el-menu-item>
      <el-menu-item index="2" disabled>
        <template slot="title">
          <div class="line"></div>
          <div class="header-circle bg-icon-2"></div>
          <span>消息中心</span>
        </template>
      </el-menu-item>
      <el-submenu index="3" >
        <template slot="title">
          <div class="end-line"></div>
          <div class="header-circle bg-icon-3"></div>
          <span>账户管理</span>
        </template>
          <el-menu-item index="3-1" disabled>
             <template slot="title">
              <div class="line"></div>
              <div class="circle"></div>
              <span>基本信息</span>
            </template>
          </el-menu-item>
          <el-menu-item index="3-2" disabled>
             <template slot="title">
              <div class="line"></div>
              <div class="circle"></div>
              <span>银行卡管理</span>
            </template>
          </el-menu-item>
          <el-menu-item index="3-2" disabled>
             <template slot="title">
              <div class="line"></div>
              <div class="circle"></div>
              <span>密码修改</span>
            </template>
          </el-menu-item>
      </el-submenu>
      </el-menu>
  </nav>
</template>
<style lang="less">
  .nav-menu{
    li i[class*='el-icon-arrow-down']:before{
    content: none;
  }
  ul{
        background: rgb(25,123,118);
        border-right: none;
  }
  ul li span{
    color: #fff;
  }
  ul li.el-menu-item.is-active{
    background: #33bcb9;
    span{
        color: black;
      }
  } 
  .el-submenu__title:hover, .el-menu-item:hover{
    background: #0f6f6d;
  }
  .el-menu-item{
    padding-left: 55px !important;
  }
  .el-submenu .el-menu-item{
    min-width: 100px;
    
  }
  .line{
    width: 1px;
    top: 0;
    bottom: 0;
    left: 32px;
    position: absolute;
    border-color: inherit;
    background-color: #c0c4cc;
  }
  .start-line{
    .line;
    top:20px;
  }
  .end-line{
    .line;
    bottom:20px;
  }
  .is-opened .end-line{
    .line;
    bottom:0px;
  }
  .circle{
    border: 1px solid #fff;
    border-radius: 50%;
    width: 10px;
    height: 10px;
    position: absolute;
    left: 26px;
    top: 14px;
    .bg-color-pink;
  }
  .header-circle{
    .circle;
    left:20px;
    width: 20px;
    height: 20px;
  }
  .bg-color-pink{
    background-color: rgb(46, 176, 172);
  }
  .bg-icon-1{
    background: url(~@/assets/img/juxin_13.png) center no-repeat;
    .bg-color-pink;
  }
  .bg-icon-2{
    background: url(~@/assets/img/juxin_14.png) center no-repeat;
    .bg-color-pink;
  }
  .bg-icon-3{
    background: url(~@/assets/img/juxin_15.png) center no-repeat;
    .bg-color-pink;
  }
  .el-submenu__title{
    padding-left: 55px !important;
  }
  .el-menu--inline{
    li{
      .el-submenu__title;   
      padding: 0 0;
    }
  }
  } 
</style>

<script>
export default {
  name: "Nav",
  data(){
    return {
      activeIndex: 'myar',
      
    }
  },
  methods:{
    handleSelect(key, keyPath) {
        //console.log(key, keyPath);
      }
  }
}
</script>
