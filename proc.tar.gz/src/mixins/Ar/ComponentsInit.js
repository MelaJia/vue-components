import HeaderSection from '@/components/HeaderSection'
export default {
  components: {
    HeaderSection
  }
}
